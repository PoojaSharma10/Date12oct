package com.flp.ems.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.util.Validate;

public class AddServlet extends HttpServlet {
	private EmployeeServiceImpl employeeServiceImpl;
	private Scanner sc;
	SimpleDateFormat dateFormat;
	private HashMap<String, Object> hashmap;
	private int EmployeeId, PhoneNo, DepartmentId, ProjectId, RolesId;
	private String Name, KinId = "GS_100", EmailId = "xyz@gmail.com", Address, date;
	private Date DateOfBirth, DateOfjoining;
	public AddServlet() throws SQLException, IOException {
		sc = new Scanner(System.in);
		hashmap = new HashMap<String, Object>();
		dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		employeeServiceImpl = new EmployeeServiceImpl();
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
       String action=request.getParameter("AddApplication");
       if(action!=null)
       {  hashmap.put("EmployeeId", 202);
		hashmap.put("EmailId", EmailId);
		hashmap.put("KinId", KinId);
		hashmap.put("DepartmentId", 11);
		hashmap.put("RolesId", 21);
		hashmap.put("ProjectId", 1);
		Name = request.getParameter("Name");
		hashmap.put("Name", Name);
		
		PhoneNo = Integer.parseInt(request.getParameter("Phone"));
		hashmap.put("PhoneNo", PhoneNo);
		
		Address = request.getParameter("Address");
		hashmap.put("Address", Address);
		
		date = request.getParameter("DateOfBirth");
		try {
			// Parsing the String
			if (Validate.isThisDateValid(date, "dd-MM-yyyy"))
				DateOfBirth = dateFormat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		hashmap.put("DateOfBirth", DateOfBirth);
		
		date = request.getParameter("StartDate");
		try {
			// Parsing the String
			if (Validate.isThisDateValid(date, "dd-MM-yyyy"))
				DateOfjoining = dateFormat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		hashmap.put("DateOfjoining", DateOfjoining);

		try {
			employeeServiceImpl.addEmployee(hashmap);
		} catch (SQLException e) {
			e.printStackTrace();
		}

       }
       
	}

	
}
